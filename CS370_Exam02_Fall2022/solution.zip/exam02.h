#define TABLE_SIZE 10.0f
#define POT_X 2.0f
#define POT_Z 2.0f
#define STACK_X -2.0f
#define STACK_Z -2.0f
#define CUP_X 0.0f
#define CUP_Z 2.0f