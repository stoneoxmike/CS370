#define TABLE_SIZE 8.0f
#define TARGET_Y 0.0f
#define TARGET_X -0.5f
#define TARGET_Z 1.0f
#define CIRCLE_RAD 2.3f
